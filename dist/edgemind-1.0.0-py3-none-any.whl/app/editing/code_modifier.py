"""
EdgeMind Code Modifier V2

Generates modified or converted source code using local Ollama LLMs.
Never writes files directly.
"""

import re
from app.editing.models import EditRequest
from app.models.ollama_client import generate_response


def clean_generated_code(code: str) -> str:
    """
    Strips markdown code blocks, introductory text, and trailing commentary from LLM output.
    """
    text = code.strip()

    # Extract content inside markdown code blocks if present
    if "```" in text:
        match = re.search(r"```(?:[a-zA-Z0-9+#\-]+)?\s*(.*?)\s*```", text, re.DOTALL)
        if match:
            text = match.group(1).strip()
        else:
            text = text.replace("```", "")

    # Remove conversational lead-in phrases ("Here is the updated code...", "Below is the Python version:")
    text = re.sub(r"^(?:Here|Below|Here is|Below is|This is).*?:\s*\n", "", text, flags=re.IGNORECASE)

    # Remove conversational trailer phrases ("Hope this helps!", "Let me know if...")
    text = re.sub(r"\n(?:Hope this helps|Let me know|Enjoy|Feel free).*$", "", text, flags=re.IGNORECASE)

    return text.strip()


def modify_code(request: EditRequest) -> str:
    """
    Generate updated or converted source code via local LLM.
    Propagates analysis findings into prompt if available.
    """
    system_prompt = f"""You are a Principal Software Engineer.
Your task is to modify or convert source code strictly according to user instructions.

Original Language: {request.source_language}
Target Language: {request.target_language}
Operation Mode: {request.operation.upper()}

RULES:
1. Return ONLY the complete updated/converted target source code.
2. Do NOT include markdown code block formatting (```).
3. Do NOT include explanations, introduction, or commentary.
4. Preserve existing comments, structure, and formatting wherever appropriate.
5. Never truncate code or leave placeholders like '// TODO: rest of code'.
"""

    analysis_context = ""
    if request.analysis_result:
        analysis_context = f"\nPrior Analysis Findings & Bug Diagnosis:\n<analysis-findings>\n{request.analysis_result[:2000]}\n</analysis-findings>\n"

    prompt = f"""User Instruction:
{request.instruction}
{analysis_context}
Operation: {"Create a new target file from source" if request.operation == "create" else "Modify existing file in-place"}
Source File Path: {request.file_path}
Target File Path: {request.target_file or request.file_path}

Source Code Data:
<{request.source_language}-source>
{request.source_code}
</{request.source_language}-source>

Return the complete modified or converted source code in target language ({request.target_language}).
"""

    raw_response = generate_response(
        prompt=prompt,
        model=request.model,
        system_prompt=system_prompt,
    )

    return clean_generated_code(raw_response)