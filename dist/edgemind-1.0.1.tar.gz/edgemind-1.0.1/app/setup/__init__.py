"""EdgeMind Setup Subpackage"""
